<?php include __DIR__ .'/header.php'; ?>
	<section class="site-archives-section site-archives-tag">
		<header class="site-archives-header">
			<h1 class="site-archives-title"><span><?php $plxShow->lang('TAG'); ?></span> : <span><?php $plxShow->tagName(); ?></span></h1>
			<p class="rss"><?php $plxShow->tagFeed() ?></p>
		</header>     
<?php include __DIR__ .'/post.php'; ?>
	  </section>
<?php include __DIR__ .'/footer.php'; ?>
