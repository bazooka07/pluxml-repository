<?php
if(!defined('PLX_ROOT')) exit;
while($plxShow->plxMotor->plxRecord_arts->loop()) {
	$thumbnail = $plxShow->artThumbnail(ART_THUMBNAIL_TEMPLATE, false);
?>
	<article class="site-post" id="site-post-<?php echo $plxShow->artId(); ?>">
		<header class="site-post-header">
			<h2 class="site-post-title"><?php $plxShow->artTitle('link'); ?></h2>
		</header>
		<footer class="site-post-footer grid">
			<div>
				<?php $plxShow->lang('WRITTEN_BY'); ?> <span class="site-post-author"><?php $plxShow->artAuthor() ?></span>
			</div><div>
				<?php $plxShow->lang('WRITTEN_ON'); ?>
				<time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day  #hour:#minute'); ?>">
				<span class="site-post-date"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></span>
				<?php $plxShow->lang('WRITTEN_AT'); ?>
				<span class="site-post-time"><?php $plxShow->artDate('#hour:#minute'); ?></span>
				</time>
			</div>
		</footer>
		<div class="site-post-content<?php if($thumbnail !== false) echo ' has_thumbnail'; ?>">
<?php
if($thumbnail !== false) { echo $thumbnail; }
?>
			<div class="site-post-main">
				<?php $plxShow->artChapo(''); ?>
				<?php $plxShow->artReadMore('<p class="site-post-more no-print"><a href="#art_url" title="#art_title">'.$plxShow->getlang('MORE').'</a></p>'); ?>
			</div>
		</div>
		<aside class="site-post-aside grid">
			<div>
				<?php $plxShow->lang('CATS') ?> <span class="site-post-cats"><?php $plxShow->artCat(''); ?></span>
			</div><div>
				<?php $plxShow->lang('TAGS') ?> <span class="site-post-tags"><?php $plxShow->artTags('<a class="#tag_status" href="#tag_url" title="#tag_name">#tag_name</a>', '') ?></span>
			</div><div>
				<span class="site-post-comm"><?php $plxShow->artNbCom(); ?></span>
			</div>
		</aside>
	</article>
<?php
}
?>
<nav class="site-post-pagination">
<?php $plxShow->pagination(); ?>
</nav>