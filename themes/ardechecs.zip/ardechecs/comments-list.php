<?php if(!defined('PLX_ROOT')) exit; ?>
	<section class="site-comments">
		<header class="site-comments-header">
			<h1 class="site-comments-title" id="comments"><?php echo $plxShow->artNbCom(); ?></h1>
		</header>
		<ul class="site-comments-list">
<?php while($plxShow->plxMotor->plxRecord_coms->loop()) { # On boucle sur les commentaires ?>
			<li id="<?php $plxShow->comId(); ?>" class="site-comments-item <?php $plxShow->comLevel(); ?>">
				<div id="com-<?php $plxShow->comIndex(); ?>">
					<p class="site-comments-info">
						<span class="site-comments-order"><a class="" href="<?php $plxShow->ComUrl(); ?>">#<?php echo $plxShow->plxMotor->plxRecord_coms->i+1 ?></a></span>
						<?php $plxShow->lang('WRITTEN_BY'); ?> <?php $plxShow->comAuthor('link'); ?> <?php $plxShow->lang('WRITTEN_ON'); ?> <time datetime="<?php $plxShow->comDate('#num_year(4)-#num_month-#num_day #hour:#minute'); ?>"><?php $plxShow->comDate('#day #num_day #month #num_year(4)'); ?> <?php $plxShow->lang('WRITTEN_AT'); ?> <?php $plxShow->comDate('#hour:#minute'); ?></time>
					</p>
					<p class="site-comments-content type-<?php $plxShow->comType(); ?>"><?php $plxShow->comContent(); ?></p>
				</div>
			</li>
<?php } # Fin de la boucle sur les commentaires ?>
	</ul>
	</section>
