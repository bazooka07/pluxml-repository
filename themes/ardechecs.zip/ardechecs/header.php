<?php
if(!defined('PLX_ROOT')) exit;
const ART_THUMBNAIL_TEMPLATE = <<< EOT
			<div class="site-post-thumbnail">
				<a href="#img_url" target="_blank">
					<img class="art_thumbnail" src="#img_thumb_url" alt="#img_alt" title="#img_title" #img_size />
				</a>
			</div>\n
EOT;
?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang(); ?>">
<head>
	<meta charset="<?php $plxShow->charset('min'); ?>" />
	<meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0" />
	<title><?php $plxShow->pageTitle(); ?></title>
<?php $plxShow->meta('description'); ?>
<?php $plxShow->meta('author'); ?>
	<link rel="icon" href="<?php $plxShow->racine(); ?>favicon.png" />
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/knacss-unminified.css" media="all" />
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/theme.css" media="all" />
<?php $plxShow->templateCss() ?>
<?php $plxShow->pluginsCss() ?>
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('RSS_ARTICLES') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('RSS_COMMENTS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
</head><body class="site site-<?php $plxShow->mode(true) ?>">
	<header class="site-header no-print">
		<div id="logo">
			<a href="<?php $plxShow->urlrewrite(); ?>"><img src="<?php echo $plxShow->plxMotor->urlRewrite($plxShow->plxMotor->aConf['medias']); ?>site/logo.svg" alt="Logo" /></a>
		</div>
		<h1 class="site-header-title"><?php $plxShow->mainTitle('link'); ?></h1>
		<div class="site-header-skiplinks">
			<!-- http://nemesisdesign.net/blog/accessibility/nice-css-skip-links-appearing-focus/ -->
			<a href="#mainmenu"><?php $plxShow->lang('GOTOMENU') ?></a>
			<a href="#maincontent"><?php $plxShow->lang('GOTOMAIN') ?></a>
		</div>
		<span class="site-header-subtitle"><?php $plxShow->subTitle(); ?></span>
	</header>
	<nav class="site-navigation no-print">
		<input type="checkbox" id="site-toggle-menu">
		<label for="site-toggle-menu">&#9776;</label>
		<ul class="site-navigation-list" id="mainmenu">
<?php $plxShow->staticList($plxShow->getLang('HOME')); ?>
		</ul>
	</nav>
<?php
$dirMedias = $plxShow->plxMotor->aConf['medias'].'site/bandeau/';
$urlMedias = $plxShow->plxMotor->urlRewrite($dirMedias);
if(
	$plxShow->mode() === 'home' and
	is_dir(PLX_ROOT.$dirMedias)
) {
	$files = glob(PLX_ROOT.$dirMedias.'*.jpg');
?>
	<div id="bandeau" class="no-print">
		<img src="<?php echo $urlMedias; ?>0380x.jpg" alt="bandeau"
		srcset="
		<?= $urlMedias; ?>0380x.jpg 380w,
		<?= $urlMedias; ?>0770x.jpg 770w,
		<?= $urlMedias; ?>1024x.jpg 1024w,
		<?= $urlMedias; ?>1960x.jpg 1960w" />
	</div>
<?php
}
?>
	<div class="site-main<?php if(defined('FULL_WIDTH')) { echo ' full-width'; } ?>">
		<main id="main-content">
