<?php if(!defined('PLX_ROOT')) exit; ?>
	<section class="site-commment no-print">
		<header class="site-form-header">
			<h1 class="site-form-title"><?php $plxShow->lang('WRITE_A_COMMENT') ?></h1>
		</header>
		<form id="site-comment-form" action="<?php $plxShow->artUrl(); ?>#form" method="post">
			<div>
				<label for="id_name"><?php $plxShow->lang('NAME') ?></label>
				<input id="id_name" name="name" type="text" maxlength="30" required>
			</div><div>
				<label for="id_mail"><?php $plxShow->lang('EMAIL') ?></label>
				<input id="id_mail" name="mail" type="text">
			</div><div>
				<label for="id_site"><?php $plxShow->lang('WEBSITE') ?></label>
				<input id="id_site" name="site" type="text">
			</div><div class="one-line">
				<label for="id_content"><?php $plxShow->lang('COMMENT') ?></label>
				<textarea id="id_content" name="content" maxlength="6000" required></textarea>
			</div><div>
				<?php $plxShow->comMessage('#com_message'); ?>
			</div>
<?php if($plxShow->plxMotor->aConf['capcha']) { ?>
			<div class="capcha">
				<p>
					<label for="id_rep"><?php $plxShow->capchaQ(); ?></label>
					<em><?php echo $plxShow->lang('ANTISPAM_WARNING') ?></em>
				</p><p>
					<input id="id_rep" name="rep" type="text">
				</p>
			</div>
<?php } ?>
			<div class="footer">
				<input type="hidden" id="id_parent" name="parent" value="<?php $plxShow->comGet('parent',''); ?>" />
				<button type="submit"><?php $plxShow->lang('SEND') ?></button>
			</div>
		</form>
	</section>
	<p class="rss"><?php $plxShow->comFeed('rss',$plxShow->artId()); ?></p>
