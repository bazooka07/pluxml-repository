<?php if(!defined('PLX_ROOT')) exit; ?>
	<aside class="site-aside no-print">
		<figure>
			<figcaption>Championnat de ligue Jeunes 2019</figcaption>
			<div class="site-aside-content">
				<ul>
					<li><a href="<?php $plxShow->urlrewrite('index.php?static7/championnat-jeunes-ara-2018'); ?>">Hébergement</a></li>
					<li><a href="https://echecs-annonay.fr/static/plan" target="_blank">Plan d'accès</a></li>
                    <li><a href="https://www.ligue-ara-echecs.fr/evenement/championnat-de-ligue-jeunes-2019/" target="_blank">Fiche championnat (<em>Ligue</em>)</a></li>
				</ul>
			</div>

		</figure>
		<figure id="lastart-list" class="site-aside-figure">
			<figcaption class="site-aside-title"><?php $plxShow->lang('LATEST_ARTICLES'); ?></figcaption>
			<div class="site-aside-content">
				<ul class="site-aside-list">
					<?php $plxShow->lastArtList('<li class="site-aside-item"><a class="#art_status" href="#art_url">#art_title</a></li>'); ?>
				</ul>
				<p class="rss"><a href="<?php $plxShow->urlRewrite('feed.php?rss') ?>"><?php $plxShow->lang('RSS_ARTICLES'); ?></a></p>
			</div>
		</figure>
		<figure id="lastcom-list" class="site-aside-figure">
			<figcaption class="site-aside-title"><?php $plxShow->lang('LATEST_COMMENTS'); ?></figcaption>
			<div class="site-aside-content">
				<ul class="site-aside-list">
					<?php $plxShow->lastComList('<li class="site-aside-item"><a href="#com_url">#com_content(55)</a> '.$plxShow->getLang('WRITTEN_BY').' #com_author</li>'); ?>
				</ul>
				<p class="rss"><a href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires'); ?>"><?php $plxShow->lang('RSS_COMMENTS'); ?></a></p>
			</div>
		</figure>
<?php
/*
		<figure id="cat-list" class="site-aside-figure">
			<figcaption class="site-aside-title"><?php $plxShow->lang('CATEGORIES'); ?></figcaption>
			<div class="site-aside-content">
				<ul class="site-aside-list">
					<?php $plxShow->catList('','<li class="site-aside-item" id="#cat_id"><a class="#cat_status" href="#cat_url">#cat_name</a> (#art_nb)</li>'); ?>
				</ul>
			</div>
		</figure>
 * */
?>
		<figure id="tag-list" class="site-aside-figure">
			<figcaption class="site-aside-title"><?php $plxShow->lang('TAGS'); ?></figcaption>
			<div class="site-aside-content">
				<ul class="site-aside-list">
					<?php $plxShow->tagList('<li class="site-aside-item tag #tag_size"><a class="#tag_status" href="#tag_url">#tag_name</a></li>'); ?>
				</ul>
			</div>
		</figure>
		<figure id="arch-list" class="site-aside-figure">
			<figcaption class="site-aside-title"><?php $plxShow->lang('ARCHIVES'); ?></figcaption>
			<div class="site-aside-content">
				<select id="archivesSelect"  class="site-aside-list">
<?php $plxShow->archList('<option value="#archives_url">#archives_name (#archives_nbart)</option>'."\n"); ?>
				</select>
				<input type="button" value="Ok" onclick="window.location = document.getElementById('archivesSelect').value;" />
			</div>
		</figure>
		<div class="txtcenter"><a href="https://framalistes.org/sympa/subscribe/ardechecs" target="_blank">S'abonner à notre liste de diffusion</a></div>
	</aside>