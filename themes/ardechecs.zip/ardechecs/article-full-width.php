<?php
const FULL_WIDTH = true;
include __DIR__ .'/article.php';
?>
