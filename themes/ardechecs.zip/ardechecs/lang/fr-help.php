<?php if (!defined('PLX_ROOT')) exit; ?>
<div class="col med-10">

<p class="float-left"><img alt="" src="<?php echo PLX_CORE ?>admin/theme/images/preview.png" width="200"/></p>

<p class="text-justify">Ce thème est conçu pour les intégrateurs web, débutants ou non. Il est fait pour commencer une intégration depuis zéro. Ce thème (plus exactement, ce <i>no theme</i>) n'est pas un framework : plutôt une boîte vide dans laquelle ranger ses propres outils plutôt que ceux tout prêt et pas toujours utiles des frameworks css traditionnels.</p>

<p class="text-justify">L'ambition de ce thème est de prendre place à côté du thème par défaut de PluXml. Le thème par défaut est propre et efficace et permet à PluXml &mdash;&nbsp;contrairement à d'autres CMS&nbsp;&mdash; d'être immédiatement utilsable après son installation.<br />
Malheureusement, lorsqu'il faut en modifier le design, on s'aperçoit que le framework css associé est très envahissant. Soit on décide de le garder et il faut alors en étudier les subtilités, soit on préfère travailler avec un autre framework (ou sans aucun framework) et il faut alors nettoyer TOUTES les balises <code>html</code> des classes devenues inutiles.</p>

<p class="text-justify"><strong>pluxzero</strong> est un thème vierge qui vient aplanir cet inconvénient en proposant des fichiers html revus et corrigés et intégrant le minimum de classes nécessaires pour démarrer un nouveau design.</p>

<p class="text-justify">Ces classes sont récapitulées dans le fichier <code>pluxzero.classes.css</code> contenu dans le dossier <strong>css</strong>.<br />
Ces classes sont nommées logiquement selon le bloc parent. Par exemple&#8239;: <code>.site-header</code>, <code>.site-header-title</code>,  <code>.site-header-subtitle</code>, etc.<br />
Autant que possible, les classes présentes dans le <code>core</code> de PluXml ont été intégrées à ce fichier (notamment les classes des liens de pagination).</p>

<p class="text-justify">Aucune de ces classes n'a de propriété par défaut de façon à pouvoir effectuer toute sorte de tests.<br />
Il est conseillé de dupliquer ce fichier avant d'entamer des modifications.</p>

<p class="text-justify">Ce thème fournit également une page complète de balises <code>html</code> «&#8239;prête à l'emploi&#8239;». Il suffit de remplacer le contenu de la page statique par défaut de PluXml par le contenu du fichier <code>css/balises.html</code>. Ce fichier est plus complet, mieux organisé et permet d'avoir une vision immédiate des propriétés css appliquées par le designer. Ce fichier est également utile, si besoin, pour choisr un framework adapté au thème en construction.<br />
VOIR&#8239;: <a href="https://github.com/cbracco/html5-test-page" rel="nofollow" hreflang="en">Liste des balises html5</a></p>

<p class="text-justify">L'architecture HTML5 a été revue de façon à mieux correspondre aux standards du W3C.<br />
L'exemple typique est celui du fichier <code>sidebar.php</code>, renommé ici <code>aside.php</code>.<br />
Les blocs d'origine ont été remplacés par l'élément <code>figure</code> qui présente l'avantage de pouvoir utiliser <code>figcaption</code> comme titre de bloc plutôt qu'un <code>h3</code> qui n'a pas, dans ce contexte, de valeur sémantique.<br />
Les rôles «&#8239;ARIA&#8239;» ont été supprimés puisque rendues caducs pae les balises sémantiques HTML5.<br /> 
VOIR&#8239;: <a href="https://www.w3.org/TR/html53/grouping-content.html#the-figure-element" rel="nofollow" hreflang="en">L'élément <code>figure</code> sur le site du W3C</a><br />
VOIR&#8239;: <a href="https://www.w3.org/TR/html-aria/#rules-wd" rel="nofollow" hreflang="en">Rôles ARIA et HTML5 sur le site du W3C</a></p>

<p class="text-justify">Les <code>skip-links</code> font leur retour ! Ces liens sont essentiels à la navigation pour les utilisateurs d'assistances technologiques. Ils sont placés juste après le titre du site parce que c'est là qu'est leur place.<br />
VOIR&#8239;: <a href="http://nemesisdesign.net/blog/accessibility/nice-css-skip-links-appearing-focus/" rel="nofollow" hreflang="en">Nécessité des skip-links et pourquoi il faut les placer après le titre principal.</a></p>

<p class="text-justify">
Toujours sur le registre de l'accessibilité, les attributs <code>title</code> sur les liens et les attributs <code>placeholder</code> pour les éléments <code>input</code> ont été supprimés. Ils n'apportent aucune information supplémentaire et se contentent de doublonner, soit l'intitulé du lien, soit l'intitulé du label. Ce qui est un gros risque de confusion pour les navigateurs vocaux.<br />
Malheureusement, le <code>core</code> de PluXml comporte beaucoup de liens et autant d'attributs <code>title</code> que les thèmes ne peuvent pas gérer&#8230;<br />
VOIR&#8239;: <a href="https://developer.paciellogroup.com/blog/2011/02/html5-accessibility-chops-the-placeholder-attribute/" rel="nofollow" hreflang="en">L'attribut <code>placeholder</code> sur le site du Paciello Group</a><br />
VOIR&#8239;: <a href="https://developer.paciellogroup.com/blog/2013/01/using-the-html-title-attribute-updated/" rel="nofollow" hreflang="en">L'attribut <code>title</code> sur le site du Paciello Group</a><br />
VOIR&#8239;: <a href="https://silktide.com/i-thought-title-text-improved-accessibility-i-was-wrong/" rel="nofollow" hreflang="en">Pourquoi il ne faut pas utiliser l'attribut <code>title</code> dans les liens</a></p>

<p class="text-justify">Le point polémique&#8230;<br />
Le fichier <code>commentaires.php</code> a été coupé en deux&#8239;: un fichier pour la liste des commentaires publiés et un fichier pour le formulaire. Du coup la fonction de réponse à un commentaire particulier a été supprimée. D'une part (excuse minable), j'ai fait face à un bug que je n'ai pas su résoudre, d'autre part (excuse facile), je ne suis pas fan de cette fonction. Le but d'un commentaire est de discuter de l'article. S'il y a un besoin de discussions entre commentateurs, un forum me paraît plus approprié (quoi, mauvaise foi&#8239;?).</p>

<p class="text-justify">Le fichier de langue a été modifié pour correspondre aux changements ci-dessus. Come je ne suis pas polyglotte, seuls les fichiers <code>fr.php</code> et <code>en.php</code> sont présents. Ce dernier servira facilement de base pour les autres langues, si nécessaire.</p>

<p class="text-justify">Dans la mesure du possible, la ponctuation a été intégrée au fichier de langue. Puisque la ponctuation diffère d'une langue à une autre (absence d'espace insécable en anglais, par exemple), elle doit également être traduisible.</p>

<p class="text-justify">Enfin, un fichier <code>post.php</code> a été ajouté de manière à n'avoir plus qu'un seul fichier pour tout le code commun aux fichiers <code>home.php</code>, <code>archives.php</code>, <code>categorie.php</code> et <code>tag.php</code> qui conservent cependant leur en-tête propre bien que remanié.<br />
Une évolution possible de ce thème serait de n'avoir plus que le fichier <code>post.php</code> et d'utiliser un code conditionnel pour l'affichage des différents en-têtes.<br />
Si un vrai dev passe par là&#8230;&#8239;:)</p>

<p class="text-justify">Requêtes et réclamations sont à adresser soit (de préférence) sur le forum (section Vos Créations -> [THÈME] pluxzero), soit dans les commentaires du <a href="https://eriicj.xyz/plx/th/pluxzero/">site de démonstration en ligne</a>.</p>

<p class="text-justify">Un dépôt github (ou équivalent) ainsi qu'un site dédié sont à l'étude.</p>

<p>Enjoy!</p>
</div>