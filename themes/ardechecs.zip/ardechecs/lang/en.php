<?php

$LANG = array(

#header.php
'GOTOMENU'            => 'Go to the main menu',
'GOTOMAIN'            => 'Go to the main content',
'MENU'                => 'Menu',
'HOME'                => 'Home',
'RSS_COMMENTS'        => 'Rss feeds for comments',
'RSS_ARTICLES'        => 'Rss feeds for articles',

# aside.php
'CATEGORIES'          => 'Categories',
'LATEST_ARTICLES'     => 'Latest articles',
'LATEST_COMMENTS'     => 'Latest Comments',
'ARCHIVES'            => 'Archives',

# footer.php
'POWERED_BY'          => 'Généré par',
'PLUXML'              => 'Blog or Cms without SQL database',
'IN'                  => 'in',
'ADMINISTRATION'      => 'Administration',
'ITSALONGWAYTOTHETOP' => 'Return to the top',
'TOP'                 => 'Top',

# erreur.php
'ERROR'               => 'The page you\'ve asked for can\'t be found',
'GOIN_BACK_HOME'      => 'Back to the home page',

# common
'WRITTEN_BY'         => 'by',
'WRITTEN_ON'         => 'on',
'WRITTEN_AT'         => 'at',
'MORE'               => 'Read more&#8230;',
'CATS'               => 'Categorie(s):',
'TAGS'               => 'Tag(s):',
'THE_AUTHOR'         => 'The author:',        
'AUTHOR_FACE'        => 'Author\'s avatar',

# archives.php, categorie.php, tags.php
'ARCHIVE'            => 'Archives for',
'CAT'                => 'categorie',
'TAG'                => 'tag',

# commentaires.php
'WRITE_A_COMMENT'    => 'Write a comment',
'NAME'               => 'You name or pseudo:',
'WEBSITE'            => 'Your website (not required):',
'EMAIL'              => 'Your email address (not required):',
'COMMENT'            => 'Your message:',
'SEND'               => 'Send',
'COMMENTS_CLOSED'    => 'Comments are closed.',
'ANTISPAM_WARNING'   => '(This is an anti-spam checking.)',

);

?>