<?php
defined('PLX_ROOT') or exit;
$src = $plxShow->plxMotor->urlRewrite($plxShow->plxMotor->aConf['medias']).'site/logo.svg';
?>
	<div id="site-lightbox" class="no-print">
		<div>
			<figure>
				<div>
					<img id="site-lightbox-img" src="<?= $src; ?>" />
				</div>
				<figcaption id="site-lightbox-title">
					<span id="site-lightbox-titleText"></span>
					<span id="site-lightbox-counter"></span>
				</figcaption>
			</figure>
		</div>
		<div id="site-lightbox-gallery">
			<button id="site-lightbox-prev" class="prev-next  icon-arrow--left" data-step="-1">
			</button>
			<div id="site-lightbox-thumbnails"></div>
			<button id="site-lightbox-next" class="prev-next icon-arrow--right" data-step="+1">
			</button>
		</div>
		<button id="site-lightbox-close">❌</button>
		<div id="site-lightbox-loading">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
	</div>
	<script type="text/javascript" src="<?php $plxShow->template(); ?>/js/script.js"></script>
