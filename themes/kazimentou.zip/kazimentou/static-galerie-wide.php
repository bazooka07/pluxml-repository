<?php include 'header.php'; ?>
<section>
	<div id="container">
		<div class="full-width">
			<article role="article" id="static-page-<?php echo $plxShow->staticId(); ?>">
				<section>
					<?php $plxShow->staticContent(); ?>
				</section>
<?php include 'galerie.php'; ?>
			</article>
		</div>
	</div>
</section>
<?php include 'footer.php'; ?>
