<?php include '/header.php'; ?>
	<main class="main grid" role="main">
		<section class="content col sml-12 med-9">
			<?php $plxShow->lang('TAG'); ?> : <?php $plxShow->tagName(); ?>
<?php include 'posts.php'; ?>
		</section>
<?php include '/sidebar.php'; ?>
	</main>
<?php include '/footer.php'; ?>