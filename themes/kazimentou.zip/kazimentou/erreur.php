<?php include __DIR__ .'/header.php'; ?>
	<main class="main grid" role="main">
		<section class="col sml-12 med-9">
			<article class="article" role="article">
				<header>
					<h1><?php $plxShow->lang('ERROR'); ?></h1>
				</header>
				<section>
					<p>
						<?php $plxShow->erreurMessage(); ?>
					</p>
				</section>
			</article>
		</section>
<?php include 'sidebar.php'; ?>
	</main>
<?php include 'footer.php'; ?>
