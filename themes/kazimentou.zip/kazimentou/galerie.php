<?php
if (!defined('PLX_ROOT')) exit;

/*
 * Template pour afficher la galerie de toutes les photos d'un dossier
 * Lors de l'édition d'un article ou d'une page statique, précisez le nom du dossier entre guillemets
 * dans le champ Balise "meta "keywords". Par exemple: "photos/nouvel-an".
 *
 * Il est possible d'indiquer plusieurs galeries. par exemple: "photos/nouvelan" "anniv"
 *
 * Utilisez un plugin comme colorBox pour avoir un diaporama:
 * http://kazimentou.fr/pluxml-plugins2/plugin=colorBox&download
 *
 * @author: Jean-Pierre Pourrez
 * */

switch ($plxMotor->mode) {
	case 'article':
		$keywords = $plxMotor->plxRecord_arts->f('meta_keywords');
		break;
	case 'static':
		$cible = $plxMotor->cible;
		$keywords = $plxMotor->aStats[$cible]['meta_keywords'];
		break;
	default:
		exit;
}
if (preg_match_all('/"([^"]+)"/', $keywords, $result)) {
	$n = 0;
	foreach($result[1] as $myFolder) {
		if (substr($myFolder, -1, 1) != '/')
			$myFolder .= '/';
?>
				<section>
					<h2>Galerie: <?php echo rtrim($myFolder, '/'); ?></h2>
<?php
		$dir = PLX_ROOT.$plxShow->plxMotor->aConf['medias'].$myFolder;

		// Récupération et affichage de la liste des images sous forme de liste
		$glob = plxGlob::getInstance($dir);

		if ($files = $glob->query('/[a-z0-9-_]+.tb.(jpg|gif|png)$/i')) { ?>
					<p class="gallery">
<?php
		    $n++;
		    foreach($files as $filename) {
		        $thumbnail = $plxShow->plxMotor->racine.$plxShow->plxMotor->aConf['medias'].$myFolder.$filename;
		        $href = str_replace('.tb', '', $thumbnail);
		        $title = str_replace('.tb', '', $filename);
		        $title = substr($title, 0, strrpos($title, '.'));
		        $size = getimagesize($dir.$filename);
		        $sizeStr = $size[3];
		        echo <<< EOT
				        <a href="$href" title="$title" rel="lightbox-$n"><img src="$thumbnail" alt="$title" $sizeStr /></a>

EOT;
			} ?>
				    </p>
<?php	} else { ?>
					<p id="no_picture">Il n'y a aucune image dans la galerie.</p>
<?php	} ?>
				</section>
<?php
	}
} else
	echo <<< NO_GALLERY
				<p id="no_gallery"><strong>Aucune galerie d'images</strong></p>
NO_GALLERY;
?>