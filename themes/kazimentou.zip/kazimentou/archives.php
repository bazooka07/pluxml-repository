<?php include 'header.php'; ?>
	<main class="main grid" role="main">
		<section class="content col sml-12 med-9">
			<ul class="repertory menu breadcrumb">
				<li><a href="<?php $plxShow->racine() ?>"><?php $plxShow->lang('HOME'); ?></a></li>
				<li><?php echo plxDate::formatDate($plxShow->plxMotor->cible, $plxShow->lang('ARCHIVES').' #month #num_year(4)') ?></li>
			</ul>
<?php include 'posts.php'; ?>
		</section>
		<?php include 'sidebar.php'; ?>
	</main>
<?php include 'footer.php'; ?>
