<?php include 'header.php'; ?>
	<main class="main grid" role="main">
		<section class="content col sml-12">
			<ul class="repertory menu breadcrumb">
				<li><a href="<?php $plxShow->racine() ?>"><?php $plxShow->lang('HOME'); ?></a></li>
				<li><?php $plxShow->catName(); ?>
				<?php $plxShow->catDescription(' : #cat_description'); ?></li>
			</ul>
<?php include 'posts.php'; ?>
		</section>
	</main>
<?php include 'footer.php'; ?>
