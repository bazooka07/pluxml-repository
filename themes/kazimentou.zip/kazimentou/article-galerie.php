<?php include 'header.php'; ?>
	<main class="main grid" role="main">
		<section class="col sml-12 med-9">
			<article class="article" role="article" id="post-<?php echo $plxShow->artId(); ?>">
				<header>
					<h1><?php $plxShow->artTitle(); ?></h1>
					<div>
						<div>
							<?php $plxShow->lang('WRITTEN_BY'); ?> <?php $plxShow->artAuthor() ?> -
							<time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></time>
						</div>
						<div>
							<a href="#comments" title="<?php $plxShow->artNbCom(); ?>"><?php $plxShow->artNbCom(); ?></a>
						</div>
					</div>
				</header>
				<section>
					<?php $plxShow->artContent(); ?>
				</section>
<?php include 'galerie.php'); ?>
				<footer>
					<div>
						<?php $plxShow->lang('CLASSIFIED_IN') ?> : <?php $plxShow->artCat() ?>
					</div>
					<div>
						<?php $plxShow->lang('TAGS') ?> : <?php $plxShow->artTags() ?>
					</div>
				</footer>
			</article>
			<?php $plxShow->artAuthorInfos('<div class="author-infos">#art_authorinfos</div>'); ?>
<?php include 'commentaires.php'; ?>
		</section>
		<?php include 'sidebar.php'; ?>
	</main>
<?php include 'footer.php'; ?>