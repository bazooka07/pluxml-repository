<?php
if(!defined('PLX_ROOT')) { exit;  }
include __DIR__ .'/header.php';
?>
	<article class="site-single" id="site-post-<?php echo $plxShow->artId();  if(defined('FULL_WIDTH')) echo ' site-full-width'; ?>">
		<header class="site-single-header">
			<h1 class="site-single-title"><?php $plxShow->artTitle(); ?></h1>
		</header>
		<footer class="site-single-footer grid">
			<div>
				<?php $plxShow->lang('WRITTEN_BY'); ?> <span class="site-single-author"><?php $plxShow->artAuthor() ?></span>
			</div><div>
				<?php $plxShow->lang('WRITTEN_ON'); ?>
				<time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day  #hour:#minute'); ?>">
				<span class="site-single-date"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></span>
				<?php $plxShow->lang('WRITTEN_AT'); ?>
				<span class="site-single-time"><?php $plxShow->artDate('#hour:#minute'); ?></span>
				</time>
			</div>
		</footer>

		<div class="site-single-content">
			<div class="site-single-thumbnail">
				<?php $plxShow->artThumbnail(ART_THUMBNAIL_TEMPLATE); ?>
			</div>
			<div class="site-single-main">
				<?php $plxShow->artContent(); ?>
			</div>
	    </div>

	    <aside class="site-single-aside grid">
				<div>
					<?php $plxShow->lang('CATS') ?> <span class="site-single-cats"><?php $plxShow->artCat() ?></span>
				</div><div>
					<?php $plxShow->lang('TAGS') ?> <span class="site-single-tags"><?php $plxShow->artTags() ?></span>
				</div>
	    </aside>

<?php
/*
    <figure class="site-single-authorbio">
      <figcaption class="site-single-authorbio-title"><?php $plxShow->lang('THE_AUTHOR') ?></figcaption>
      <div class="site-single-authorbio-content">
        <p><img alt="<?php $plxShow->lang('AUTHOR_FACE') ?>" src="<?php $plxShow->template(); ?>/img/user.png"> <?php $plxShow->artAuthorInfos('#art_authorinfos'); ?></p>
      </div>
    </figure>
* */
?>
	</article>
<?php
if($plxShow->plxMotor->plxRecord_coms) {
	include __DIR__ .'/comments-list.php';
}
if($plxShow->plxMotor->plxRecord_arts->f('allow_com') and $plxShow->plxMotor->aConf['allow_com']) {
	include __DIR__ .'/comments-form.php';
} else { ?>
	<p><?php $plxShow->lang('COMMENTS_CLOSED') ?>.</p>
<?php
}
include __DIR__ .'/footer.php';
?>
