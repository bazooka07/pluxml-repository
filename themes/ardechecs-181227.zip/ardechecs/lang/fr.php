<?php

$LANG = array(
	#header.php
	'GOTOMENU'				=> 'Aller au menu principal',
	'GOTOMAIN'				=> 'Aller au contenu principal',
	'MENU'					=> 'Menu',
	'HOME'					=> 'Accueil',
	'RSS_COMMENTS'			=> 'Fil Rss des commentaires',
	'RSS_ARTICLES'			=> 'Fil Rss des articles',

	# aside.php
	'CATEGORIES' 			=> 'Catégories',
	'LATEST_ARTICLES'		=> 'Articles récents',
	'LATEST_COMMENTS'		=> 'Commentaires récents',
	'ARCHIVES'				=> 'Archives',

	# footer.php
	'POWERED_BY'			=> 'Généré par',
	'PLUXML'	        	=> 'Blog ou Cms sans base SQL',
	'IN'					=> 'en',
	'ADMINISTRATION'		=> 'Administration',
	'ITSALONGWAYTOTHETOP'	=> 'Remonter en haut de page',
	'TOP'					=> 'Haut de page',

	# erreur.php
	'ERROR'					=> 'La page que vous avez demandée n\'existe pas',
	'GOIN_BACK_HOME'		=> 'Retour à la page d\'accueil',

	# post.php, article.php
	'WRITTEN_BY'			=> 'Par',
	'WRITTEN_ON'			=> 'le',
	'WRITTEN_AT'			=> 'à',
	'MORE'					=> 'Lire la suite &#8230;',
	'CATS'					=> 'Catégorie(s)&#8239;:',
	'TAGS'					=> 'Mot(s)-clef(s)&#8239;:',
	'THE_AUTHOR'			=> 'L\'auteur(e)&#8239;:',
	'AUTHOR_FACE'			=> 'Avatar de l\'auteur(e)',

	# archives.php, categorie.php, tags.php
	'ARCHIVE'				=> 'archives',
	'CAT'					=> 'catégorie',
	'TAG'					=> 'mot-clef',

	# commentaires.php
	'WRITE_A_COMMENT'		=> 'Écrire un commentaire',
	'NAME'					=> 'Votre nom ou pseudo&#8239;:',
	'WEBSITE'				=> 'Votre site Internet&#8239;:',
	'EMAIL'					=> 'Votre adresse e-mail&#8239;:',
	'COMMENT'				=> 'Contenu de votre message&#8239;:',
	'SEND'					=> 'Envoyer votre commentaire',
	'COMMENTS_CLOSED'		=> 'Les commentaires sont fermés.',
	'ANTISPAM_WARNING'		=> '(Ceci est une vérification anti-spam)',
);
?>
