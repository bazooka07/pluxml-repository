<?php
if(!defined('PLX_ROOT')) { exit; }

const ART_THUMBNAIL_TEMPLATE = <<< EOT
			<div class="site-post-thumbnail">
				<a href="#img_url" target="_blank">
					<img class="art_thumbnail" src="#img_thumb_url" alt="#img_alt" title="#img_title" #img_size />
				</a>
			</div>\n
EOT;

const IMG_BEGIN = <<< IMG_BEGIN
		<img %ssrc="%s" alt="%s" class="bandeau" srcset="
IMG_BEGIN;
const IMG_SET = <<< IMG_SET
\n			%s %sw
IMG_SET;
const IMG_END = <<< IMG_END
\n		"/>\n
IMG_END;

$sitePath = $plxShow->plxMotor->aConf['medias'].'site/';
const LOGO_NAME = 'logo.svg';
if(!file_exists($sitePath.LOGO_NAME)) {
	$sitePath = $plxShow->plxMotor->aConf['racine_themes'].$plxShow->plxMotor->style.'/'.'img/';
}
$logoSrc = $plxShow->plxMotor->urlRewrite($sitePath.LOGO_NAME);
?>
<!DOCTYPE html>
<html lang="<?php $plxShow->defaultLang(); ?>">
<head>
	<meta charset="<?php $plxShow->charset('min'); ?>" />
	<meta name="viewport" content="width=device-width, user-scalable=yes, initial-scale=1.0" />
	<title><?php $plxShow->pageTitle(); ?></title>
<?php $plxShow->meta('description'); ?>
<?php $plxShow->meta('author'); ?>
	<link rel="icon" href="<?php $plxShow->template(); ?>/favicon.ico" />
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/knacss-unminified.css" media="all" />
	<link rel="stylesheet" href="<?php $plxShow->template(); ?>/css/theme.css" media="all" />
<?php $plxShow->templateCss() ?>
<?php $plxShow->pluginsCss() ?>
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('RSS_ARTICLES') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss') ?>" />
	<link rel="alternate" type="application/rss+xml" title="<?php $plxShow->lang('RSS_COMMENTS') ?>" href="<?php $plxShow->urlRewrite('feed.php?rss/commentaires') ?>" />
</head><body class="site site-<?php $plxShow->mode(true) ?>">
	<header class="site-header no-print">
		<div id="logo">
			<a href="<?php $plxShow->urlrewrite(); ?>"><img src="<?php echo $logoSrc; ?>" alt="Logo" /></a>
		</div>
		<h1 class="site-header-title"><?php $plxShow->mainTitle('link'); ?></h1>
		<div class="site-header-skiplinks">
			<!-- http://nemesisdesign.net/blog/accessibility/nice-css-skip-links-appearing-focus/ -->
			<a href="#mainmenu"><?php $plxShow->lang('GOTOMENU') ?></a>
			<a href="#maincontent"><?php $plxShow->lang('GOTOMAIN') ?></a>
		</div>
		<span class="site-header-subtitle"><?php $plxShow->subTitle(); ?></span>
	</header>
	<nav class="site-navigation no-print">
		<input type="checkbox" id="site-toggle-menu">
		<label for="site-toggle-menu">&#9776;</label>
		<ul class="site-navigation-list" id="mainmenu">
<?php $plxShow->staticList($plxShow->getLang('HOME')); ?>
		</ul>
	</nav>
<?php
$dirMedias = $sitePath.'bandeau/';
$urlMedias = $plxShow->plxMotor->urlRewrite($dirMedias);
if($plxShow->mode() === 'home') {
	$files = glob(PLX_ROOT.$dirMedias.'*.jpg');
	if(!empty($files)) {
?>
	<div id="slideshow-overlay" class="bandeau no-print">
<?php
		$img = false;
		$next = false;
		foreach(array_map(function($item) { return preg_replace('@^\./@', '', $item); }, $files) as $fl) {
			if(preg_match('@([^/]*\w)[_\s-]*(\d{4})x\.jpg$@', $fl, $matches)) {
				if($img != $matches[1]) {
					if(!empty($img)) { echo IMG_END; }
					$prefix = (!empty($img)) ? 'data-' : '';
					printf(IMG_BEGIN, $prefix, $fl, $matches[1]);
					$img = $matches[1];
					$next = false;
				} else {
					if($next) { echo ','; } else { $next = true; }
					printf(IMG_SET, $fl, $matches[2]);
				}
			}
		}
		if(!empty($img)) { echo IMG_END; }
?>
	</div>
<?php
	}
}
?>
	<div class="site-main<?php if(defined('FULL_WIDTH')) { echo ' full-width'; } ?>">
		<main id="main-content">
