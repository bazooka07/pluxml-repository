<?php include __DIR__ .'/header.php'; ?>
	<section class="site-archives-section site-archives-categorie<?php if(defined('FULL_WIDTH')) echo ' site-full-width';  ?>">
		<header class="site-archives-header">
			<h1 class="site-archives-title"><span><?php $plxShow->lang('CAT'); ?></span> : <span><?php $plxShow->catName(); ?></span></h1>
			<p class="site-archives-description"><?php $plxShow->catDescription('#cat_description'); ?></p>
			<p class="rss"><?php $plxShow->artFeed('rss',$plxShow->catId()); ?></p>
		</header>			
<?php include __DIR__ .'/post.php'; ?>
	</section>
<?php include __DIR__ .'/footer.php'; ?>
