<?php
const FULL_WIDTH = true;
include __DIR__ .'/static.php';
?>
