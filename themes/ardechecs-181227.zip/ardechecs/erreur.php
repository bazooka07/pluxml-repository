<?php include __DIR__ .'/header.php'; ?>
	<article class="site-page site-page-<?php echo $plxShow->staticId(); ?>" id="site-page-<?php echo $plxShow->staticId(); ?>">
		<header class="site-page-header">
			<h1 class="site-page-title"><?php $plxShow->lang('ERROR'); ?></h1>
		</header>
		<div class="site-page-content">
			<?php $plxShow->erreurMessage(); ?>
		</div>
	</article>
<?php include __DIR__ .'/footer.php'; ?>
