<?php include __DIR__ .'/header.php'; ?>
	<article class="site-page site-page-<?php echo $plxShow->staticId(); if(defined('FULL_WIDTH')) echo ' site-full-width'; ?>" id="site-page-<?php echo $plxShow->staticId(); ?>">
<?php
if(!empty(($plxShow->plxMotor->aStats[$plxShow->plxMotor->cible]['group']))) {
?>
		<header class="site-page-header">
			<h1 class="site-page-title"><?php $plxShow->staticTitle(); ?></h1>
		</header>
<?php
}
?>
		<div class="site-page-content">
			<?php $plxShow->staticContent(); ?>
		</div>
	</article>
<?php include __DIR__ .'/footer.php'; ?>
