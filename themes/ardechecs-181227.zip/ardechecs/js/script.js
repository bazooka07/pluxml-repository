(function() {
	// Afiche un diaporama à partir des vignettes d'images.
	'use strict';

	const SLIDESHOW_DELAY = 2000; // milliseconds

	const overlay = document.getElementById('site-lightbox');
	// const gallery = document.getElementById('site-lightbox-gallery');
	const gallery = document.getElementById('site-lightbox-thumbnails');
	const img = document.getElementById('site-lightbox-img');
	const caption = document.getElementById('site-lightbox-titleText');
	const counter = document.getElementById('site-lightbox-counter');
	const loading = document.getElementById('site-lightbox-loading');
	const PATTERN_CSS = 'img[src$=".tb.jpg"], img[src$=".tb.JPG"], img[src$=".tb.png"]';
	const REGEX1 = /\.tb(\.jpe?g|\.png)$/i;
	const imgsList = document.querySelectorAll(PATTERN_CSS);

	var pos = 0;
	var timer1 = null;

	const tempImg = new Image();

	function showImg() {
		img.src = tempImg.src;

		// Lazy loading
		if(imgsList.length > 1) {
			const n = (pos + 1) % imgsList.length;
			if(!imgsList[n].hasAttribute('data-loaded')) {
				const img = new Image();
				img.src = imgsList[n].src.replace(REGEX1, '$1');
				imgsList[n].setAttribute('data-loaded', '');
			}
		}
	}

	function updateImageSize() {
		const computed = getComputedStyle(img);
		const maxHeight0 = parseInt(computed['max-height']);
		const maxWidth0 = parseInt(computed['max-width']);

		const h0 = maxHeight0;
		const ratio = tempImg.width / tempImg.height;
		var h, w;
		if(h0 * ratio < maxWidth0) {
			// height is the limit
			h = (tempImg.height < h0) ? tempImg.height : h0;
			w = Math.round(h * ratio);
		} else {
			// width is the limit
			w = (tempImg.width < maxWidth0) ? tempImg.width : maxWidth0;
			h = Math.round(w / ratio);
		}

		img.style.height = h + 'px';
		img.style.width = w + 'px';
	}

	tempImg.addEventListener('load', function(event) {
		// img is loaded
		loading.classList.remove('active');
		updateImageSize();
		showImg();
	});

	img.addEventListener('transitionend', function(event) {
		// img is resized
		img.style.height = '';
		img.style.width = '';
	});

	function showMe(event) {
		var el = null;
		switch(event.target.tagName) {
			case 'A':
				el = event.target.querySelector(PATTERN_CSS);
				break;
			case 'IMG':
				if(!event.target.classList.contains('active')) {
					el = event.target;
					if(el.hasAttribute('data-id')) {
						// thumbnail in the gallery
						el = imgsList[el.getAttribute('data-id')];
					}
				}
				break;
			case 'BUTTON':
				if(event.target.hasAttribute('data-step')) {
					pos += parseInt(event.target.getAttribute('data-step'));
					if(pos < 0) { pos = imgsList.length - 1; }
					if(pos > imgsList.length - 1) { pos = 0; }
					el = imgsList[pos];
				}
				break;
		}

		if(el == null) { return; }
		var title = el.title.trim();
		if(title == '') {
			title = el.alt.trim();
			if(title == '') {
				title = decodeURIComponent(el.src)
					.replace(/.*\/(?:\d+-)?([^\/]+)\.(?:jpe?g|png)$/i, '$1')
					.replace(/.tb$/, '')
					.replace(/_/, ' ');
			}
		}
		caption.textContent = title;
		document.body.classList.add('lightbox');

		img.style.width = img.width + 'px';
		img.style.height = img.height + 'px';
		// img.parentElement.style.backgroundImage = 'url(' + img.src + ')';
		// img.classList.add('fade');
		setTimeout(function() {
			overlay.classList.add('show');
			tempImg.src = el.src.replace(REGEX1, '$1');
			loading.classList.add('active');
		}, 20);

		// Gallery
		if(imgsList.length > 1) {
			const activeImg = gallery.querySelector('img.active');
			if(activeImg != null) { activeImg.classList.remove('active'); }
			for(var i=0, iMax=imgsList.length; i<iMax; i++) {
				if(el.src === imgsList[i].src) {
					imgsList[i].setAttribute('data-loaded', '');
					const thumbnail = document.getElementById('site-lightbox-thumb-' + i);
					thumbnail.classList.add('active');
					thumbnail.scrollIntoView();
					pos = i;
					counter.innerHTML = (i + 1) + ' / ' + imgsList.length; // fine no-breaking space: &#8239;
					break;
				}
			}
		}
		event.preventDefault();
	}

	// https://developer.mozilla.org/en-US/docs/Web/Events/transitionend
	overlay.addEventListener('transitionend', function(event) {
		if(
			event.propertyName == 'opacity' &&
			!event.target.classList.contains('show')
		) {
			overlay.classList.remove('active');
		}
	});

	if(imgsList != null) {
		const closeBtn = document.getElementById('site-lightbox-close');
		const prevBtn = document.getElementById('site-lightbox-prev');
		const nextBtn = document.getElementById('site-lightbox-next');

		for(var i=0, iMax=imgsList.length; i<iMax; i++) {
			imgsList[i].parentElement.addEventListener('click', showMe);
		}

		closeBtn.addEventListener('click', function(event) {
			document.body.classList.remove('lightbox');
			if(imgsList.length > 1) {
				// can be disabled by the z key
				overlay.classList.add('multi');
			}
		});

		if(imgsList.length > 1) {
			overlay.classList.add('multi');
			prevBtn.addEventListener('click', showMe);
			nextBtn.addEventListener('click', showMe);
			gallery.innerHTML = '';
			for(var i=0, iMax=imgsList.length; i<iMax; i++) {
				const img = document.createElement('IMG');
				img.src = imgsList[i].src;
				img.title = imgsList[i].title;
				img.id = 'site-lightbox-thumb-' + i;
				img.setAttribute('data-id', i);
				gallery.appendChild(img);
			}
			gallery.addEventListener('click', showMe);
		} else {
			overlay.classList.remove('multi');
		}
		img.style.width = '20vh';

		// shortkeys on the keyboard
		window.addEventListener('keydown', function(event) {
			if(
				document.body.classList.contains('lightbox') &&
				!event.shiftKey &&
				!event.ctrlKey &&
				!event.altKey &&
				!event.prevented &&
				event.key != 'F11' &&
				event.key != 'F12' &&
				event.key != 'F5'
			) {
				event.preventDefault();
				if(
					timer1 != null &&
					event.key != 'p' &&
					event.key != 'P'
				) {
					// Stops the slide show
					clearInterval(timer1);
					timer1 = null;
					overlay.classList.remove('slideshow');
					updateImageSize();
				} else {
					switch(event.key) {
						case ' ':
						case 'Enter':
						case 'Right':
						case 'ArrowRight':
						case 'n':
						case 'N':
							if(imgsList.length > 1) { nextBtn.click(); }
							break;
						case 'Backspace':
						case 'Left':
						case 'ArrowLeft':
						case 'b':
						case 'B':
							if(imgsList.length > 1) { prevBtn.click(); }
							break;
						case 'Esc':
						case 'Escape':
							closeBtn.click();
							break;
						case 'Home':
							const firstThumbnail = document.getElementById('site-lightbox-thumb-0');
							if(firstThumbnail != null) { firstThumbnail.click(); }
							break;
						case 'p':
						case 'P':
							if(imgsList.length > 1) {
								if(timer1 == null) {
									overlay.classList.add('slideshow');
									overlay.mozRequestFullScreen();
									nextBtn.click();
									timer1 = setInterval(
										function() { nextBtn.click(); },
										SLIDESHOW_DELAY
									);
								} else {
									overlay.classList.remove('slideshow');
									clearInterval(timer1);
									timer1 = null;
								}
							}
							updateImageSize();
							break;
						case 'End':
							const lastThumbnail = document.getElementById('site-lightbox-thumb-' + (imgsList.length - 1));
							if(lastThumbnail != null) { lastThumbnail.click(); }
							break;
						case 'z':
						case 'Z':
							overlay.classList.toggle('zoom');
							updateImageSize();
							break;
						default:
							console.log(event.key);
					}
				}
			}
		});
	}
})();

/**
 * Gestion d'un slideshow automatique en fondu enchainé.
 * Le container doit avoir id="slideshow-overlay".
 * */
(function(containerId) {
	'use strict';

	const overlay = document.getElementById(containerId);
	if(overlay != null) {
		const imgsList = overlay.getElementsByTagName('img');
		if(imgsList.length > 1) {
			var pos = 0;
			const imgPreload = new Image();

			function showMe() {
				const prevImg = overlay.querySelector('img.foreground');
				if(prevImg != null) { prevImg.classList.remove('foreground'); }
				if(imgsList[pos].classList.contains('active')) {
					imgsList[pos].classList.remove('active');
					imgsList[pos].classList.add('foreground');
				}
				pos = (pos + 1) % imgsList.length;
				// console.log('Pos: ', pos);
				imgsList[pos].classList.add('active');
				if(!imgsList[pos].hasAttribute('src') || imgsList[pos].src.trim() == '') {
					imgsList[pos].src = imgsList[pos].dataset.src;
				}
				// Lazy loading
				const n = (pos + 1) % imgsList.length;
				if(imgsList[n].hasAttribute('data-src') && imgsList[n].src.split('/').pop() != imgsList[n].dataset.src.split('/').pop()) {
					// console.log('Lazy loading: ', n);
					imgPreload.src = imgsList[n].dataset.src;
					imgsList[n].src = imgsList[n].dataset.src;
				}
			}

			const currentImg = overlay.querySelector('img[src]');
			for(var i=0, iMax=imgsList.length; i < iMax; i++) {
				if(currentImg != null && currentImg == imgsList[i]) {
					pos = (imgsList.length + i - 1) % imgsList.length;
					// console.log('Starting with img #', pos);
				}
				imgsList[i].addEventListener('transitionend', function(event) {
					this.classList.remove('foreground');
					event.preventDefault();
					// console.log('End of transition');
				});
			}

			showMe();
			var timer1 = setInterval(function() { showMe(); }, 4000);
		} else if(imgsList.length > 0) {
			imgsList[0].classList.add('active');
		}
	}
})('slideshow-overlay');

/**
 * Gestion des onglets.
 * */
(function(queryCSS) {

	function showTab(value) {
		const MASK = 'active';
		const tab = document.querySelector('label[for="' + value + '"]');
		if(tab != null) {
			const actives = tab.parentElement.querySelectorAll('label.' + MASK);
			for(var i=0, iMax=actives.length; i<iMax; i++) { actives[i].classList.remove(MASK); }
			tab.classList.add(MASK);
		}
	}

	const radios = document.body.querySelectorAll(queryCSS + ' > input[type="radio"][id]');
	for(var i=0, iMax=radios.length; i<iMax; i++) {
		radios[i].addEventListener('change', function(event) {
			showTab(this.id);
			event.preventDefault();
		});
		if(radios[i].checked) { showTab(radios[i].id); }
	}

})('div.tabs-content');
