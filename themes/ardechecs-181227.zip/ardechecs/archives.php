<?php include __DIR__ .'/header.php'; ?>
	<section class="site-archives-section site-archives-date">
		<header class="site-archives-header">
			<h1 class="site-archives-title"><span></span><?php $plxShow->lang('ARCHIVE') ?></span> : <span><?php echo plxDate::formatDate($plxShow->plxMotor->cible, '#month #num_year(4)') ?></span></h1>
		</header>
<?php include __DIR__ .'/post.php'; ?>
	</section>
<?php include __DIR__ .'/footer.php'; ?>
