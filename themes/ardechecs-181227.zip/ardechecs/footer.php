<?php if (!defined('PLX_ROOT')) exit; ?>
		</main>
<?php
if(!defined('FULL_WIDTH')) { include 'aside.php'; } ?>
	</div>
	<footer class="site-footer no-print">
		<p class="site-footer-infos">
			<span><a href="<?php $plxShow->urlrewrite('core/admin/auth.php'); ?>">&copy;</a> <?php echo date('Y'); ?></span>
		</p><p>
			<span><?php $plxShow->mainTitle('link'); ?></span>
		</p><p>
			<span><?php $plxShow->subTitle(); ?></span>
		</p>
	</footer>
<?php include __DIR__ .'/lightbox.php'; ?>
</body></html>
