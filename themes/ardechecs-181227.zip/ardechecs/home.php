<?php
if(!defined('PLX_ROOT')) { exit; }
include __DIR__ .'/header.php';
include __DIR__ .'/post.php';
include __DIR__ .'/footer.php';
?>
